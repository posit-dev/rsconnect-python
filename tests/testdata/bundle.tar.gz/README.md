rsconnect deploy api ./ --insecure -s http://localhost:7979 --api-key "S2I6qesZUkKNBhaEA7Kxod7IqcBc3pFt"
